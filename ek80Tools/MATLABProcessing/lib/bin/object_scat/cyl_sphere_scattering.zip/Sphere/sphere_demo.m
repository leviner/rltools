%% demo program to call elastic_fs.m

clear

out_flag=1;				% modular of form function
proc_flag=1;			% form function vs ka
scale=1;				% linear spacing in ka
n=1000;					% number of computation points 
x0=0.1;					% starting ka value
xe=20;					% end ka value
g=14.65;					% density ratio
hc=3.7;					% compressional sound speed contrast
hs=2.4;					% sheer speed contrast
theta=180;				% backscattering

para_ela=[n x0 xe g hc hs theta];
g=1.05;h=1/1.8;
para_fld=[n x0 xe g h theta];
para_rgd=[n x0 xe theta];

%[ka, fm]=rgd_sft_fs(proc_flag,1,scale,out_flag,para_rgd);
%[ka, fm]=elastic_fs(proc_flag,scale,out_flag,para_ela);
[ka, fm]=fluid_fs(proc_flag,scale,out_flag,para_fld);

plot(ka,fm)
xlabel('ka')
ylabel('Form Function |f|')
